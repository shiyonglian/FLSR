% =========================================================================
% ������   ����ѵ�������߷ֱ���ͼƬ�²���ָ�����ʵõ��ͷֱ���ͼ��,Ӧ���ڸߵ�
%          �ֱ���ͼ������ȡͼ�����Ϊ��ϴ�ƴ��Һ�д��hdf5�ļ���                
%          (56,12,4) 
% �ο����ף�
%  Dong C, Loy C C, Tang X. Accelerating the Super-Resolution Convolutional 
%  Neural Network[J].
%  
% ��ѧ��
% wangxuewen@yy.com
% =========================================================================
clear;close all;
%% settings
folder = '/home/li547/shiyonglian/data/Set5'; 

savepath = '3-20-set5.h5';

size_input = 20;
size_label = 58;
scale = 3;
stride = 15;
shift=scale-1;
chunksz = 128;
%% initialization
data = zeros(size_input, size_input, 1, 1);
label = zeros(size_label, size_label,1, 1);

count = 0;

%% generate data
filepaths = dir(fullfile(folder,'*.bmp'));

for i = 1:length(filepaths)
  
    image = imread(fullfile(folder,filepaths(i).name)); 
    image = rgb2ycbcr(image); 
    image=  image(:,:,1);
    image=  im2double(image);
    im_label = modcrop(image, scale);
    im_input  =imresize( im_label ,1/scale,'bicubic');
    im8=im_input;
    [hei,wid]= size(im_input);
  
    for x = 1 : stride : hei-size_input+1
        for y = 1 :stride : wid-size_input+1
             
               subim_input = im8(x : x+size_input-1, y : y+size_input-1);           
               subim_label = im_label(x*scale  : x*scale+size_label-1, y*scale : y*scale+size_label-1);
                count=count+1;
            
            data(:, :,1, count) = subim_input;
            
            label(:, :,1, count) = subim_label;
                            
              end
       
    end
end
order = randperm(count);
data = data(:, :, 1, order);
label = label(:, :, 1, order); 
created_flag = false;
totalct = 0;
totalct1 = 0;

for batchno = 1:floor(count/chunksz)
    
    last_read=(batchno-1)*chunksz;
    batchdata = data(:,:,1,last_read+1:last_read+chunksz); 
    batchlabs = label(:,:,1,last_read+1:last_read+chunksz); 
    startloc = struct('dat',[1,1,1,totalct+1], 'lab', [1,1,1,totalct+1]);   
    curr_dat_sz = store2hdf5(savepath, batchdata, batchlabs, ~created_flag, startloc, chunksz); 
       
    created_flag = true;
    
    totalct = curr_dat_sz(end);
                   
    
end
  h5disp(savepath);









