%function:enlarge data 40 bei

addpath('/home/li547/shiyonglian/data/Set5');  
addpath('/home/li547/shiyonglian/data/enlargeset5'); 
ListName=dir('/home/li547/shiyonglian/data/Set5/*.bmp');  
[Pm,Pn]=size(ListName);  
factor=[1,0.9,0.8,0.7,0.6];
for p=1:5
    fact=factor(p);
    for iPm=1:1:Pm %��ȡ�ļ�������ͼƬѭ��   
        oriImg=imread(ListName(iPm).name);    %readImg  
        for j = 1:2
            if j>1
                oriImg=flipdim(oriImg,2);
            end
            for v=0:1:3
                rimage=imrotate(oriImg,90*v);
                % cutImg=imcrop(oriImg,[50,50,255,255])  
                bi=imresize(rimage,fact);        %bi����Ϊai��0.6��  
                %endImg=imresize(cutImg,[256,256]);         %��aiת��256x256�Ĵ�С  
                iDealName=ListName(iPm).name;  
                ll = length(iDealName)-4;
                iDealName_new1 = iDealName(1:ll);
                iDealName_new=strcat(num2str(p,1),num2str(j,1),num2str(v,1));
                str1='.bmp';
                iDealAddress='/home/li547/shiyonglian/data/enlargeset5/';  
                iDealAll=strcat(iDealAddress,iDealName_new1,iDealName_new,str1);  
                % ID=imresize(cutImg,1);  
                imwrite(bi,iDealAll);
                clear bi rimage
            end
        end
    end
end

