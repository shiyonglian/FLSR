% =========================================================================
% ������   ����PSNRֵ�����粻�ϵ��ı仯���ߣ���Ҫ����min_iter,max_iter,step          
%    
% �ο����ף�
%  Dong C, Loy C C, Tang X. Accelerating the Super-Resolution Convolutional 
%  Neural Network[J].
%  
% ��ѧ��
% wangxuewen@yy.com
% =========================================================================
% addpath('/usr/local/MATLAB/R2014a/');%xiugaidedifang
addpath('/home/li547/caffe/matlab');
addpath('./evaluation_func/');
addpath('./evaluation_func/matlabPyrTools-master/');
close all;
clear all;

%% set parameters
up_scale =2;
scale = 2;
shift =scale-1;
aa=100;
test_dataset='Urban100'; % Set5 | Set14 | B100 | Urban100
folder=['/media/li547/李世民资料/syl/',test_dataset];%xiugaidedifang
model = '/media/li547/李世民资料/syl/net/2/2-30-12prelumat.prototxt';%xiugaidedifang
step =500;  
min_iter=383500;%xiugaidedifang
max_iter=383500;%xiugaidedifang

if strcmp(test_dataset,'Set5') || strcmp(test_dataset,'Set14')
    filepaths=dir(fullfile(folder,'*.bmp'));
else
    filepaths=dir(fullfile(folder,'*.jpg'));
end
count = 1;
psnr_average=0;
caffe.reset_all(); 
caffe.set_mode_gpu();
caffe.set_device(0);
net = caffe.Net(model,'test');
count1 = fix((max_iter - min_iter)/step) +1;
psnr = zeros(1,count1);
psnra = zeros(1,count1);
psnr_bica = zeros(1,count1);
 ifc_idn=zeros(length(filepaths),1);
% ssim_our=zeros(1,count1);
for fid = min_iter : step : max_iter
psnr_ours=0;
psnr_bic=0;
psnr_a=0;
ssi=0;
time_our=zeros(length(filepaths),1);
psnr_our=zeros(length(filepaths),1);
ssi_our=zeros(length(filepaths),1);
for i = 1:length(filepaths)
    i
    image = imread(fullfile(folder,filepaths(i).name));
    if size(image,3)>1
        image_ycbcr = rgb2ycbcr(image); 
        image=  image_ycbcr(:,:,1); 
        %image_ycbcr=modcrop(image_ycbcr,scale);
        %image_ycbcr=image_ycbcr(shift + 1:end,shift +1 :end,:);
    end
    image=  im2double(image);
    image = modcrop(image, scale);
    im_gnd=image;

    im_gnd = im_gnd( shift+1: end-shift,shift+1 : end-shift);
    imk=im_gnd;

    im_gnd = uint8(im_gnd * 255);

    tic;
    for v=0:1:3
        if v>=1
       image=imrotate(image,90); 
        end
%    if v==0
%    figure;
%   imshow(uint8(image*255));
%    end

        im_l = imresize(image, 1/scale, 'bicubic');

        im_b=imresize(im_l,scale,'bicubic'); 

        im8=im_l; 

        im_b=im_b(shift + 1:end,shift +1 :end);
        [m,n]=size(im_gnd);
        if v==0
        im_h=zeros(m,n);
        end
        [input_height ,input_width] = size(im8);
        input_channel = 1;
        batch =1;
        net.blobs('data').reshape([input_height input_width input_channel batch]); 
        net.reshape();
        net.blobs('data').set_data(im8);


        weights = ['/media/li547/李世民资料/syl/caffemodel/2/2-30-enlargeprelu/_iter_' num2str(fid) '.caffemodel'];%xiugaidedifang
        net.copy_from(weights);
        net.forward_prefilled();
        output = net.blobs('conv19').get_data();    
 
        if v==0
        l=output;
        l=l(1:end-shift,1:end-shift);
        l0=l*255;
         l=l*255;
        end
        if v==1
         l=imrotate(output,-v*90); 
         l=l(1:end-shift,shift+1:end);
         l1=l*255;
          l=l*255;
        end
        if v==2
         l=imrotate(output,180); 
         l=l(shift+1:end,shift+1:end);
         l2=l*255;
          l=l*255;
        end
        if v==3
        l=imrotate(output,90);  
        l=l(shift+1:end,1:end-shift);
        l3=l*255;
        l=l*255;
        end
        im_h=im_h+l; 
%     p=uint8(l*255);
%     figure;
%     imshow(p);
    end
    time_our(i)=toc;
    
%     figure;
%     imshow(uint8(l0*255));
%     figure;
%     imshow(uint8(l1*255));
%     figure;
%     imshow(uint8(l2*255));
%     figure;
%     imshow(uint8(l3*255));
    im_h=uint8(im_h/4);
%     im_k=uint8(im_h);
     lall=uint8((l0+l1+l2+l3)/4);
%     figure
%     imshow(lall);
%     im_b=uint8(im_b*255);
%       psnr0=compute_psnr(l0,im_gnd);
%         psnr1=compute_psnr(l1,im_gnd);
%           psnr2=compute_psnr(l2,im_gnd);
%             psnr3=compute_psnr(l3,im_gnd);
    psnr_ours =psnr_ours+compute_psnr(lall,im_gnd);
    psnr_our(i)= compute_psnr(lall,im_gnd);
%     psnr_bic =psnr_bic+compute_psnr(im_b,im_gnd);
   ssi =ssi+ssim_index(im_gnd,lall);
   ssi_our(i)=ssim_index(im_gnd,lall);
     %% compute IFC
%     ifc_idn(i) = ifcvec(double(im_gnd),double(im_h));
%     ifc_bic(i)=ifcvec(double(im_gnd),double(lall));
%   imwrite(lall, ['/media/li547/李世民资料/syl/caffemodel/2/urban100+',num2str(i),'.bmp']);
end



      %psnr(count) = psnr_ours;
       psnr(count) = psnr_ours/aa;
    
      if  psnr_average<psnr(count)
       psnr_average=psnr(count);
       a=fid;
       end
       count = count+1;
  
end
   ssi_average=ssi/aa;
psnr_bic_average = psnr_bic/aa;
x = min_iter : step : max_iter;

%%

%plot(x,psnr, '-r' ,x,psnr_bic/5, 'b-');% hua liang tiao xian ,xuyao geng duo de xian ji xu zai hou mian jia
% image_ycbcr(:,:,1)=im_h;
% image_h = ycbcr2rgb(image_ycbcr); 
% imwrite(image_h, ['/home/li547/shiyonglian/3_rgb_h' '.bmp']);
 %imwrite(image, ['/home/li547/shiyonglian/3_original' '.bmp']);
%imwrite(im_b, ['/home/li547/shiyonglian/3_bicubic' '.bmp']);
%imwrite(im_h, ['/home/li547/shiyonglian/3_ours' '.bmp']);
fprintf('Mean PSNR for Ours: %f dB\n',   mean(psnr_our));
fprintf('SSIM for Ours: %f dB\n', mean(ssi_our));
fprintf('Mean IFC for Our: %f \n', mean(ifc_idn)); 
fprintf('Mean Time for our: %f \n', mean(time_our));
