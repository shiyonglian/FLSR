clc;
clear all;
 scale=2;
 shift=scale-1;
 folder='/media/li547/李世民资料/syl/compare/1/';
 folder2='/media/li547/李世民资料/syl/compare/monarch/';
 filepaths = dir(fullfile(folder,'*.bmp'));
 filepaths2 = dir(fullfile(folder2,'*.png'));
ssi=zeros(length(filepaths2),1);
psnr_srcnn1=zeros(length(filepaths2),1);

for i = 1:length(filepaths2)
    i
     image = imread('/media/li547/李世民资料/syl/compare/1/monarch.bmp');%kan duo zhang
    image1 = imread(['/media/li547/李世民资料/syl/compare/monarch/',filepaths2(i).name]);   
%  image = imread('/home/li547/shiyonglian/data/Urban100/img_039.png');  %dan
%  image=image(shift :end-shift,shift :end-shift,:);
%   image1=image(shift :end-shift,shift  :end-shift,:);
%  image1 = imread('/home/li547/shiyonglian/result/a/2_urban100_im39.bmp');   
%image=image(1:764,1:1024,:);
if size(image,3)>1
    image = rgb2ycbcr(image); 
    image=  image(:,:,1);
    image1 = rgb2ycbcr(image1); 
    image1=  image1(:,:,1);
end
    image = modcrop(image, scale);
   image=  im2double(image);
   image1= im2double(image1);
%   image1=image(shift+1 :end,shift +1:end);
%    im_l = imresize(image, 1/scale, 'bicubic');
%    im_b=imresize(im_l,scale,'bicubic');
%    im_b=uint8(im_b*255);
%    image1=  im2double(image1);
   truth=uint8(image*255);
   
   our =uint8(image1 * 255);
    %im_b(:,:,1)=image1;
%     if size(im_b,3)>1
%     imagec=ycbcr2rgb(im_b);
%     end
%    imwrite(imagec, ['/home/li547/4/BSDcolor/',num2str(i),'.bmp']);
    psnr_srcnn1(i)=compute_psnr(truth,our);
    compute_psnr(truth,our)

    ssi (i)=ssim_index(truth,our);
    ssim_index(truth,our);
     
% psnrlap=compute_psnr(image,image1)
end
