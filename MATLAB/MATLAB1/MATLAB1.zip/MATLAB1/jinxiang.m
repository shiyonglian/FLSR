clear all;    
close all;    
clc;    
A=imread('/home/li547/shiyonglian/data/Set14/2.bmp');    
[height,width,dim]=size(A);  
tform=maketform('affine',[-1 0 0;0 1 0;width 0 1]);  
B=imtransform(A,tform,'nearest');%Bcun shuiping
tform2=maketform('affine',[1 0 0;0 -1 0;0 height 1]);  
C=imtransform(A,tform2,'nearest');%C cun chuizhi 
subplot(1,3,1),imshow(A);  
title('yuantu');  
subplot(1,3,2),imshow(B);  
title('shuiping');  
subplot(1,3,3),imshow(C);  
title('chuizhi');  