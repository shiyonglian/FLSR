clear all;
clc;
A=imread('/home/li547/shiyonglian/data/Set14/2.bmp');

subplot(1,3,1);
imshow(A);
title('yuantu');
B=flipdim(A,2);
subplot(1,3,2);
imshow(B);
title('jingxiang');
