% =========================================================================
% ������   ����PSNRֵ�����粻�ϵ��ı仯���ߣ���Ҫ����min_iter,max_iter,step          
%    
% �ο����ף�
%  Dong C, Loy C C, Tang X. Accelerating the Super-Resolution Convolutional 
%  Neural Network[J].
%  
% ��ѧ��
% wangxuewen@yy.com
% =========================================================================
addpath('/home/li547/caffe/matlab');%xiugaidedifang
addpath('./evaluation_func/');
addpath('./evaluation_func/matlabPyrTools-master/');
close all;
clear all;

%% set parameters
up_scale =3;
scale = 3;
shift =scale-1;
n=5;
folder='/media/li547/李世民资料/syl/ Set5';%xiugaidedifang
model = '/media/li547/李世民资料/syl/net/3/dense12prelumat.prototxt';
step =500;  
min_iter=185500 ;%xiugaidedifang
max_iter=185500;%xiugaidedifang
filepaths = dir(fullfile(folder,'*.bmp'));
count = 1;
psnr_average=0;
%% load model
caffe.reset_all(); 
caffe.set_mode_gpu();
caffe.set_device(0);
net = caffe.Net(model,'test');
count1 = fix((max_iter - min_iter)/step) +1;
psnr = zeros(1,count1);
psnra = zeros(1,count1);
psnr_bica = zeros(1,count1);
 ifc_idn=zeros(length(filepaths),1);
 time_idn=zeros(length(filepaths),1);
 
for fid = min_iter : step : max_iter
psnr_ours=0;
psnr_bic=0;
psnr_a=0;
ssi=0;


for i = 1:length(filepaths)
 image = imread(fullfile(folder,filepaths(i).name));%duo zhang
% image = imread('/home/li547/shiyonglian/data/Set14/5.bmp');  %dan
if size(image,3)>1
    image_ycbcr = rgb2ycbcr(image); 
    image=  image_ycbcr(:,:,1); 
    %image_ycbcr=modcrop(image_ycbcr,scale);
    %image_ycbcr=image_ycbcr(shift + 1:end,shift +1 :end,:);
end
image=  im2double(image);  
image = modcrop(image, scale);
im_gnd=image;

im_l = imresize(image, 1/scale, 'bicubic');
im_b=imresize(im_l,scale,'bicubic'); 
im8=im_l; 
im_b=im_b(shift + 1:end,shift +1 :end);

im_gnd = im_gnd( shift+1: end,shift+1 : end);
im_gnd = uint8(im_gnd * 255);

[input_height ,input_width] = size(im8);
input_channel = 1;
batch =1;
 tic;
net.blobs('data').reshape([input_height input_width input_channel batch]); 
net.reshape();
net.blobs('data').set_data(im8);

    weights = ['/media/li547/李世民资料/syl/caffemodel/3/3-20-enlargeprelu/_iter_' num2str(fid) '.caffemodel'];

    net.copy_from(weights);
    net.forward_prefilled();
    output = net.blobs('conv19').get_data();
   time_idn(i)=toc;

    im_h=uint8(output*255);
    im_b=uint8(im_b*255);
    %% compute PSNR
 psnr_bic =psnr_bic+compute_psnr(im_b,im_gnd);
 ssi_bic =ssi+ssim_index(im_gnd,im_b);
 psnr_ours =psnr_ours+compute_psnr(im_h,im_gnd);
ssi =ssi+ssim_index(im_gnd,im_h);
    %% compute IFC
    ifc_idn(i) = ifcvec(double(im_gnd),double(im_h));
    ifc_bic(i)=ifcvec(double(im_gnd),double(im_b));

    %% requite Reconstruction image
% imwrite(im_h, ['/media/li547/李世民资料/syl/caffemodel/2/urban100/',num2str(i),'.bmp']);
end

  


     psnr(count) = psnr_ours/n;
      if  psnr_average<psnr(count)
       psnr_average=psnr(count);
       a=fid;
       end
       count = count+1;
  
end
%% compute results
psnr_bic_average = psnr_bic/n;
ssi_bic_average=ssi_bic/n;
ssi_average=ssi/n;
%% show results
fprintf('PSNR for Bicubic Interpolation: %f dB\n', psnr_bic_average);
fprintf('SSIM for Bicubic  Interpolation: %f dB\n', ssi_bic_average);
fprintf('PSNR for net  Reconstruction: %f dB\n', psnr_average);
fprintf('SSIM for net Reconstruction: %f dB\n', ssi_average);
fprintf('Mean IFC for our: %f \n', mean(ifc_idn)); 
fprintf('Mean Time for our: %f \n', mean(time_idn));
figure, imshow(im_b); title('Bicubic Interpolation');
% imwrite(im_h, ['/home/li547/shiyonglian/jieguo/bic/',num2str(i),'comic.bmp']);
figure, imshow(im_h); title('Net  Reconstruction');
% imwrite(im_h, ['/home/li547/shiyonglian/jieguo/srcnn/',num2str(i),'comic.bmp']);

%imwrite(im_b, ['Bicubic Interpolation' '.bmp']);
% imwrite(im_h, ['Net Reconstruction' '.bmp']);
x = min_iter : step : max_iter;
plot(x,psnr, '-r' ,x,psnr_bic/n ,'b');% hua liang tiao xian ,xuyao geng duo de xian ji xu zai hou mian jia


