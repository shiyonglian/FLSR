% =========================================================================
% ������   ����PSNRֵ�����粻�ϵ��ı仯���ߣ���Ҫ����min_iter,max_iter,step          
%    
% �ο����ף�
%  Dong C, Loy C C, Tang X. Accelerating the Super-Resolution Convolutional 
%  Neural Network[J].
%  
% ��ѧ��
% wangxuewen@yy.com
% =========================================================================
addpath('/home/li547/caffe/matlab');%xiugaidedifang
close all;
clear all;

%% set parameters
up_scale =3;
scale = 3;
shift =scale-1;
folder='/home/li547/shiyonglian/data/Set5';%xiugaidedifang

model = '/home/li547/shiyonglian/net/dense20mat.prototxt';%xiugaidedifang
step =500;  
min_iter=500;%xiugaidedifang
max_iter=5000;%xiugaidedifang
filepaths = dir(fullfile(folder,'*.bmp'));
count = 1;
psnrset5average=0;
caffe.reset_all(); 
caffe.set_mode_gpu();
caffe.set_device(0);
net = caffe.Net(model,'test');
count1 = fix((max_iter - min_iter)/step) +1;
psnr = zeros(1,count1);
psnra = zeros(1,count1);
psnr_bica = zeros(1,count1);

for fid = min_iter : step : max_iter
psnr_ours=0;
psnr_bic=0;
psnr_a=0;
for i = 1 :length(filepaths)
image = imread(fullfile(folder,filepaths(i).name));


% if size(image,3)>1
%     image_ycbcr = rgb2ycbcr(image); 
%     image=  image_ycbcr(:,:,1); 
%     %image_ycbcr=modcrop(image_ycbcr,scale);
%     %image_ycbcr=image_ycbcr(shift + 1:end,shift +1 :end,:);
% end
 image=  im2double(image);
image = modcrop(image, scale);
im_gnd=image;
im_l = imresize(image, 1/scale, 'bicubic');
im_b=imresize(im_l,scale,'bicubic'); 
im8=im_l; 
im_b=im_b(shift + 1:end,shift +1 :end);
im_gnd = im_gnd( shift+1: end,shift+1 : end);
im_gnd = uint8(im_gnd * 255);
[input_height ,input_width] = size(im8);
input_channel = 1;
batch =1;

net.blobs('data').reshape([input_height input_width input_channel batch]); 


net.reshape();
net.blobs('data').set_data(im8);


    weights = ['/home/li547/shiyonglian/caffemodel/dense20caffemodel/_iter_' num2str(fid) '.caffemodel'];%xiugaidedifang
    net.copy_from(weights);
    net.forward_prefilled();
    output = net.blobs('conv19').get_data();
    
    im_h=uint8(output*255);
    im_b=uint8(im_b*255);
    psnr_ours =psnr_ours+compute_psnr(im_h,im_gnd);
    psnr_bic =psnr_bic+compute_psnr(im_b,im_gnd);
%     imwrite(im_h, ['/home/li547/shiyonglian/3set14result/',num2str(i),'.bmp']);
end
      %psnr(count) = psnr_ours;
       psnr(count) = psnr_ours/5;
 
      if  psnrset5average<psnr(count)
       psnrset5average=psnr(count);
       a=fid;
       end
       count = count+1;
  
end

psnr_bic_average = psnr_bic/5;
x = min_iter : step : max_iter;
plot(x,psnr, '-r' ,x,psnr_bic/5, 'b-');% hua liang tiao xian ,xuyao geng duo de xian ji xu zai hou mian jia
% image_ycbcr(:,:,1)=im_h;
% image_h = ycbcr2rgb(image_ycbcr); 
% imwrite(image_h, ['/home/li547/shiyonglian/3_rgb_h' '.bmp']);
 %imwrite(image, ['/home/li547/shiyonglian/3_original' '.bmp']);
%imwrite(im_b, ['/home/li547/shiyonglian/3_bicubic' '.bmp']);

